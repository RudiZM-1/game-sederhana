package id.player.jobsClass;

public interface IJobsClass {
    String getJobsClassName();
    int getJobsClassHealth();
    int getJobsClassPhysicalAttackPower();
    int getJobsClassMagicalAttackPower();
    int getJobsClassPhysicalDefensePower();
    int getJobsClassMagicalDefensePower();
}
