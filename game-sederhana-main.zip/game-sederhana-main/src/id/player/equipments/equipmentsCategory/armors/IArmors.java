package id.player.equipments.equipmentsCategory.armors;

public interface IArmors {
    String getEquipmentsCategory();
    String getArmorsName();
    int getArmorsPhysicalDefensePower();
}
