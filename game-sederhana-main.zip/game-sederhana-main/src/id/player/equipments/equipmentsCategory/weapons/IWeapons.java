package id.player.equipments.equipmentsCategory.weapons;

public interface IWeapons {
    String getEquipmentsCategory();
    String getWeaponsName();
    int getWeaponsPhysicalAttackPower();
}
